#define CONFDIR  "../Resources/"
#define SHAREDIR "../Resources/"
#define CONFFILE "config.txt"
