#define CONFDIR  "../Resources/"
#define SHAREDIR "../Resources/"
#define CONFFILE "config.txt"
#define CONFIG_OPENGL
#define CONFIG_MODPLUG