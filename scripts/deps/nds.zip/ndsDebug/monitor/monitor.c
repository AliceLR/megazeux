/*---------------------------------------------------------------------------------

$Id: monitor.c,v 1.2 2006/10/10 12:17:01 ben Exp $

Simple console print demo
-- dovoto

$Log: monitor.c,v $
Revision 1.2  2006/10/10 12:17:01  ben
*** empty log message ***

Revision 1.1.1.1  2006/09/06 10:13:19  ben
Debug start

Revision 1.4  2005/09/17 23:15:13  wntrmute
corrected iprintAt in templates
	
Revision 1.3  2005/09/05 00:32:20  wntrmute
removed references to IPC struct
replaced with API functions
	
Revision 1.2  2005/08/31 01:26:30  wntrmute
updated to work with new stdio support

Revision 1.1  2005/08/03 06:29:56  wntrmute
added templates


---------------------------------------------------------------------------------*/
//#define PRINT_DEBUG 1
#include <nds.h>
#include <nds/registers_alt.h>
#ifdef PRINT_DEBUG
#include <stdio.h>
#endif
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>

#include <stdint.h>

//#include <nds/arm9/console.h> //basic print funcionality

#ifdef TCP_DEBUG
#define DEBUGGING

/* log to the serial port */
//#define SERIAL_LOG 1
#endif

#ifdef SERIAL_DEBUG
#define DEBUGGING
#endif


#ifdef SERIAL_LOG
#include <stdio.h>

#include "spi_uart_bridge.h"
#endif

#ifdef DEBUGGING
#include "debug_stub.h"

#ifdef SERIAL_DEBUG
#include "debug_serial.h"
#endif
#ifdef TCP_DEBUG
#include "debug_tcp.h"
#endif
#endif


#define NDS_START_ADDRESS 0x02040000

void
some_thumb_code( uint8_t *an_array, uint32_t size);

/*
 * The debugger log function
 */
void
logFn_debug( const char *fmt, ...) {
#ifdef SERIAL_LOG
  static char print_buffer[100];
  int write_size;

  va_list ap;

  va_start( ap, fmt);

  write_size = vsprintf( print_buffer, fmt, ap);

  va_end( ap);

  write_spiUART( (uint8_t *)print_buffer, write_size);

  while ( getTxBufferCount_spiUART() != 0)
    poll_spiUART();
#endif
}


//---------------------------------------------------------------------------------
int
main( void) {
  //---------------------------------------------------------------------------------
  // Initialise the interrupt system
  irqInit();

#ifdef SERIAL_LOG
#define SPI_RX_BUFFER_SIZE 20
#define SPI_TX_BUFFER_SIZE 512
  static uint8_t spi_rx_buffer[SPI_RX_BUFFER_SIZE];
  static uint8_t spi_tx_buffer[SPI_TX_BUFFER_SIZE];

  /*
   * Setup the spi/uart bridge for logging
   */
  WAIT_CR &= ~0x0880;
  init_spiUART( spi_rx_buffer, SPI_RX_BUFFER_SIZE,
		spi_tx_buffer, SPI_TX_BUFFER_SIZE);
  write_spiUART( (uint8_t *)"Monitor output\n", 15);
  while ( getTxBufferCount_spiUART() != 0)
    poll_spiUART();
#endif

#ifdef PRINT_DEBUG
  powerON(POWER_ALL);
  videoSetMode(0);	//not using the main screen
  videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);	//sub bg 0 will be used to print text
  vramSetBankC(VRAM_C_SUB_BG);

  SUB_BG0_CR = BG_MAP_BASE(31);

  BG_PALETTE_SUB[255] = RGB15(31,31,31);	//by default font will be rendered with color 255

  //consoleInit() is a lot more flexible but this gets you up and running quick
  consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);
  
  iprintf("Debug monitor\n");
#endif

#ifdef SERIAL_DEBUG
  /* DS Card access ARM9:bit11=0 (needed for the spi uart bridge) GBA Cart access ARM9:bit7=0 */
  WAIT_CR &= ~0x0880;

  if ( !init_debug( &serialCommsIf_debug, NULL)) {
    /*iprintf("Failed to initialise the debugger stub - cannot continue\n");*/
    while(1);
  }
#endif

#ifdef TCP_DEBUG
 {
   struct tcp_debug_comms_init_data init_data = {
     .port = 30000
   };
   if ( !init_debug( &tcpCommsIf_debug, &init_data)) {
#ifdef PRINT_DEBUG
     iprintf("Failed to initialise the debugger stub - cannot continue\n");
#endif
     while(1);
   }
 }
#endif

  /* jump to the start function */
  //void (*start_fn)( void) = (void (*)( void))NDS_START_ADDRESS;

  //start_fn();

#ifdef SERIAL_LOG
  write_spiUART( (uint8_t *)"Ready to debug\n", 15);
#endif

  /*  consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);
      iprintf("Came back to the debugger\n");*/
  while(1) {
    debugHalt();
  }
}
