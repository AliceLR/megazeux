/*---------------------------------------------------------------------------------

$Id: main.c,v 1.1.1.1 2006/09/06 10:13:19 ben Exp $

Simple console print demo
-- dovoto

$Log: main.c,v $
Revision 1.1.1.1  2006/09/06 10:13:19  ben
Debug start

Revision 1.4  2005/09/17 23:15:13  wntrmute
corrected iprintAt in templates
	
Revision 1.3  2005/09/05 00:32:20  wntrmute
removed references to IPC struct
replaced with API functions
	
Revision 1.2  2005/08/31 01:26:30  wntrmute
updated to work with new stdio support

Revision 1.1  2005/08/03 06:29:56  wntrmute
added templates


---------------------------------------------------------------------------------*/
#include <nds.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>

#include <stdint.h>

#include <nds/arm9/console.h> //basic print funcionality

void
some_thumb_code( uint8_t *an_array, uint32_t size);


/*
 * The debugger log function
 */
void
logFn_debug( const char *fmt, ...) {
  va_list ap;

  va_start( ap, fmt);

  vprintf( fmt, ap);

  va_end( ap);
}


/* see how the ITCM is configured */
static uint32_t
get_ITCMconfig( void) {
  uint32_t config;

  asm ( "MRC p15, 0, %0, c1, c0, 0;   \r\n"
	: "=r"(config)
	:
  );

  return config;
}

static uint32_t
get_ITCMregion( void) {
  uint32_t config;

  asm ( "MRC p15, 0, %0, c9, c1, 1;   \r\n"
	: "=r"(config)
	:
  );

  return config;
}

/* enable the ITCM */
static void
enable_ITCM( void) {
  asm ( "mrc p15, 0, r0, c1, c0, 0;\r\n"
	"orr r0, r0, #0x40000;\r\n"
	"mcr p15, 0, r0, c1, c0, 0;\r\n"
	:
	:
	: "r0"
	);
}

/* disable the protection unit */
static void
disable_protectUnit( void) {
  uint32_t clear_mask = ~0x1;
  asm ( "mrc p15, 0, r0, c1, c0, 0;\r\n"
	"and r0, r0, %0;\r\n"
	"mcr p15, 0, r0, c1, c0, 0;\r\n"
	:
	: "r"(clear_mask)
	: "r0"
	);
}


static int
some_arm_code( int a, int b, int c, int d, int e) {
  int sum = a + b;

  sum += c;
  sum += d;
  sum += e;

  return sum;
}


int inside_count = 0;
/*
 * Lets see if breakpointing works in a interrupt handler
 */
static void
test_vblank_handler( void) {
  /* do some rubbish */
  inside_count += 1;

  /* FIXME: you cannot step out of here as the bios handler is in
   * ROM so no breakpoints (yet?) */
}


//---------------------------------------------------------------------------------
int
main( void) {
  int i;
  uint8_t an_array[10];

  //---------------------------------------------------------------------------------
  touchPosition touchXY;

  // Initialise the interrupt system
  irqInit();

  //powerON(POWER_ALL);
  videoSetMode(0);	//not using the main screen
  videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);	//sub bg 0 will be used to print text
  vramSetBankC(VRAM_C_SUB_BG);

  SUB_BG0_CR = BG_MAP_BASE(31);

  BG_PALETTE_SUB[255] = RGB15(31,31,31);	//by default font will be rendered with color 255

  //consoleInit() is a lot more flexible but this gets you up and running quick
  consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);

  /* Set up a video blanking handler for interrupt hander breakpoint testing */
  irqSet( IRQ_VBLANK, test_vblank_handler);
  irqEnable( IRQ_VBLANK);

  iprintf("Debug Test application\n");

  for ( i = 0; i < (int)sizeof(an_array); i++) {
    an_array[i] = i;
  }

  scanKeys();
  while(1) {
    uint32 pressed;

    scanKeys();
    pressed = keysDown();

    if ( pressed & KEY_A) {
      iprintf("Button A pressed\n");
    }

    if ( pressed & KEY_X) {
      uint32_t itcm_config;
      iprintf("Button X pressed\n");
      itcm_config = get_ITCMconfig();
      iprintf("ITCM %08x\n", itcm_config);
    }
    if ( pressed & KEY_Y) {
      iprintf("Button Y pressed\n");
      enable_ITCM();
    }
    if ( pressed & KEY_B) {
      uint32_t write_value = 0x55555555;
      uint32_t read_value;
      iprintf("Button B pressed\n");
#if 0
      /* this will break the debugger if the protection unit is not disabled */
      iprintf("Writing into the ITCM\n");
      asm ( "mov r0, #0x00000000;\r\n"
	    "str %0, [r0];\r\n"
	    :
	    : "r"(write_value)
	    : "r0"
	    );
      iprintf("Reading from the ITCM\n");
      asm ( "mov r0, #0x00000000;\r\n"
	    "ldr %0, [r0];\r\n"
	    : "=r"(read_value)
	    :
	    : "r0"
	    );
      iprintf("Read %08x from itcm\n");
#endif
    }

    if ( pressed & KEY_LEFT) {
      iprintf("LEFT pressed\n");
      DC_FlushAll();
      disable_protectUnit();
    }

    if ( pressed & KEY_UP) {
      uint32_t itcm_region;
      iprintf("UP pressed\n");

      itcm_region = get_ITCMregion();
      iprintf("ITCM region reg %08x\n", itcm_region);
    }

    if ( pressed & KEY_DOWN) {
      iprintf("DOWN pressed\n");

      some_thumb_code( an_array, sizeof( an_array));

      some_arm_code( 1, 2, 3, 4, 5);
    }


    touchXY=touchReadXY();
    //iprintf("\x1b[10;0HTouch x = %04X, %04X\n", touchXY.x, touchXY.px);
    //iprintf("\x1b[11;0HTouch y = %04X, %04X\n", touchXY.y, touchXY.py);
  }

  return 0;
}
