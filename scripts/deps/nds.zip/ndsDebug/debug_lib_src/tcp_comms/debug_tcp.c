/*
 * $Id: debug_tcp.c,v 1.2 2006/10/10 12:12:16 ben Exp $
 */
/** \file
 * \brief The debug stub TCP network comms.
 */
#include <nds.h>

#include <stdlib.h>
#include <stdint.h>

#include <dswifi9.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include <debug_stub.h>
#include "debug_tcp.h"

#ifdef DO_LOGGING
#define LOG( fmt, ...) logFn_debug( fmt, ##__VA_ARGS__)
#else
#define LOG( fmt, ...)
#endif


/** The Listening socket */
static int listen_sock;

/** The socket connected to GDB */
static int gdb_socket;


// Dswifi stub functions
void *
sgIP_malloc(int size) {
  return malloc(size);
}
void
sgIP_free(void * ptr) {
  free(ptr);
}

// sgIP_dbgprint only needed in debug version
void
sgIP_dbgprint(char * txt __attribute__((unused)), ...) {		
}

// wifi timer function, to update internals of sgIP
static void
Timer_50ms(void) {
  Wifi_Timer(50);
}


// notification function to send fifo message to arm7
static void
arm9_synctoarm7() { // send fifo message
  REG_IPC_FIFO_TX=0x87654321;
}

// interrupt handler to receive fifo messages from arm7
static void
arm9_fifo() { // check incoming fifo messages
  int syncd = 0;
  while ( !(REG_IPC_FIFO_CR & IPC_FIFO_RECV_EMPTY)) {
    u32 value = REG_IPC_FIFO_RX;
    if ( value == 0x87654321 && !syncd) {
      syncd = 1;
      Wifi_Sync();
    }
  }
}



/*
 * The initialisation function
 */
static int
init_fn( void *data __attribute__((unused))) {
  struct tcp_debug_comms_init_data *init_data =
    (struct tcp_debug_comms_init_data *)data;
  int success_flag = 0;

  LOG("Initialising TCP comms\n");

  if ( init_data == NULL) {
    LOG("Have not been given initialisation data.\n");
    return 0;
  }

  REG_IPC_FIFO_CR = IPC_FIFO_ENABLE | IPC_FIFO_SEND_CLEAR; // enable & clear FIFO
		

  LOG("Initialising Wifi\n");
  u32 Wifi_pass= Wifi_Init(WIFIINIT_OPTION_USELED|WIFIINIT_OPTION_USEHEAP_64);
  REG_IPC_FIFO_TX=0x12345678;
  REG_IPC_FIFO_TX=Wifi_pass;
   	
  *((volatile u16 *)0x0400010E) = 0; // disable timer3
		
  LOG("Setting up interrupt handlers\n");
  irqSet(IRQ_TIMER3, Timer_50ms); // setup timer IRQ
  irqEnable(IRQ_TIMER3);
  irqSet(IRQ_FIFO_NOT_EMPTY, arm9_fifo); // setup fifo IRQ
  irqEnable(IRQ_FIFO_NOT_EMPTY);

  REG_IPC_FIFO_CR = IPC_FIFO_ENABLE | IPC_FIFO_RECV_IRQ; // enable FIFO IRQ

  LOG("Setting sync handler\n");
  Wifi_SetSyncHandler(arm9_synctoarm7); // tell wifi lib to use our handler to notify arm7

  // set timer3
  *((volatile u16 *)0x0400010C) = -6553; // 6553.1 * 256 cycles = ~50ms;
  *((volatile u16 *)0x0400010E) = 0x00C2; // enable, irq, 1/256 clock

  LOG("Waiting for ARM7\n");
  while( Wifi_CheckInit() == 0) { // wait for arm7 to be initted successfully
    while( REG_VCOUNT > 192); // wait for vblank
    while( REG_VCOUNT < 192);
  }

  LOG("Connecting to AP\n");
  Wifi_AutoConnect(); // request connect

  int assoc_status;
  do {
    assoc_status = Wifi_AssocStatus();
  } while( assoc_status != ASSOCSTATUS_ASSOCIATED &&
	   assoc_status != ASSOCSTATUS_CANNOTCONNECT);

  if ( assoc_status == ASSOCSTATUS_CANNOTCONNECT) {
    LOG( "Could not connect - cannot continue\n");
  }
  else {
    uint32_t ip_addr = Wifi_GetIP();
    struct sockaddr_in sain;

    LOG( "Connected to AP successfully\n");
    LOG( "My IP %lu.%lu.%lu.%lu gdb port %d\n", ip_addr & 0xff, (ip_addr >> 8) & 0xff, (ip_addr >> 16) & 0xff,
	 (ip_addr >> 24) & 0xff, init_data->port);

    /* create the listening socket and wait for a connection */
    sain.sin_addr.s_addr = 0;
    sain.sin_family = AF_INET;
    sain.sin_port = htons( init_data->port);
    listen_sock = socket( AF_INET,SOCK_STREAM, 0);
    bind( listen_sock, (struct sockaddr *)&sain, sizeof(sain));

    int temp_flag = 1;
    ioctl( listen_sock, FIONBIO, &temp_flag);
    listen( listen_sock, 2);

    LOG( "Waiting for GDB to connect\n");
    do {
      int addr_size = sizeof( sain);
      gdb_socket = accept( listen_sock, (struct sockaddr *)&sain, &addr_size);
    } while ( gdb_socket == -1);

    LOG( "GDB connected\n");
    success_flag = 1;
  }

  return success_flag;
}



static void
writeByte_fn( uint8_t byte) {
  //LOG("Sending byte %02x %c\n", byte, byte);
  send( gdb_socket, &byte, 1, 0);
}


static void
writeData_fn( uint8_t *buffer, uint32_t count) {
  //LOG("Sending byte %02x %c\n", byte, byte);
  send( gdb_socket, buffer, count, 0);
}

static int
readByte_fn( uint8_t *read_byte) {
  int read_good = 0;
  int read_len;

  read_len = recv( gdb_socket, read_byte, 1, 0);

  if ( read_len == 1) {
    //LOG("TCP DEBUG read byte %02x %c\n", *read_byte, *read_byte);
    read_good = 1;
  }

  return read_good;
}


static void
poll_fn( void) {
  /* The TCP socket is interrupt driven */
}


static uint32_t
irqs_fn( void) {
  /* Timer and Fifo interrupts are needed */
  return IRQ_TIMER3 | IRQ_FIFO_NOT_EMPTY;
}


/** The instance of the comms function interface */
struct comms_fn_iface_debug tcpCommsIf_debug = {
  .init_fn = init_fn,

  .readByte_fn = readByte_fn,

  .writeByte_fn = writeByte_fn,

  .writeData_fn = writeData_fn,

  .poll_fn = poll_fn,

  .get_IRQs = irqs_fn
};

