#ifndef _DEBUG_SERIAL_H_
#define _DEBUG_SERIAL_H_ 1
/*
 * $Id: debug_serial.h,v 1.1.1.1 2006/09/06 10:13:19 ben Exp $
 */
/** \file
 */


/**
 */
extern struct comms_fn_iface_debug serialCommsIf_debug;


#endif /* End of _DEBUG_SERIAL_H_ */
