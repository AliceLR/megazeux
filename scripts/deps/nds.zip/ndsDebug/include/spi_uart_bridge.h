#ifndef _SPI_UART_BRIDGE_H_
#define _SPI_UART_BRIDGE_H_ 1
/*
 * $Header$
 */
/** \file
 * \brief A driver for a SPI UART bridge.
 *
 * This driver can configure and send/receive data across the SPI UART bridge.
 * The SPI side of the bridge is connected to the SPI bus of the DS card slot.
 */
#ifdef __cplusplus
extern "C" {
#endif

/** \brief Initialise the bridge driver.
 *
 * Initialise the SPI UART bridge driver, setting up the Tx and Rx fifos
 * to use the supplied buffers.
 * Initialises the Card SPI driver.
 * <b>NOTE:</b> for polling to work correctly the IRQ_CARD_LINE irq must not
 * be enabled, i.e. do not call irqEnable( IRQ_CARD_LINE).
 *
 * \param rx_buffer The buffer for use by the receive fifo.
 * \param rx_buffer_size The size (in bytes) of the receive buffer.
 * \param tx_buffer The buffer for use by the transmit fifo.
 * \param tx_buffer_size The size (in bytes) of the transmit buffer.
 */
void
init_spiUART( uint8_t *rx_buffer, uint32_t rx_buffer_size,
	      uint8_t *tx_buffer, uint32_t tx_buffer_size);


/** \brief Prepares the bridge to use interrupts.
 *
 * Installs an interrupt handler for the DS card SPI interrupt.
 * Installs an interrupt handler for the DS card interrupt.
 * <b>NOTE:</b> irqInit() must have been called before calling this function.
 */
void
prepareIRQs_spiUART( void);


/** \brief Poll the bridge.
 *
 * Transfers any outstanding data across the SPI bus.
 * <b>NOTE:</b> do not call if the bridge is interrupt driven.
 *
 * \return The number of bytes received across the bridge.
 */
uint32_t
poll_spiUART( void);


/** \brief Write bytes to the SPI UART bridge.
 *
 * \param buffer The buffer containing the data to be written.
 * \param size The number of bytes to be written out.
 *
 * \return The number of bytes actually written out.
 */
uint32_t
write_spiUART( const uint8_t *buffer, uint32_t size);


/** \brief read bytes from the SPI UART bridge.
 *
 * \param buffer The buffer in which the read data will be placed.
 * \param max_size The maximum number of bytes to be read.
 *
 * \return The number of bytes actually read into the buffer.
 */
uint32_t
read_spiUART( uint8_t *buffer, uint32_t max_size);


/** \brief Get the number of bytes waiting to be sent across the bridge.
 *
 * \return The number of bytes.
 */
uint32_t
getTxBufferCount_spiUART( void);


/** \brief Get the number of bytes available for reading.
 *
 * \return The number of bytes.
 */
uint32_t
getRxBufferCount_spiUART( void);

#ifdef __cplusplus
};
#endif

#endif /* End of _SPI_UART_BRIDGE_H_ */
