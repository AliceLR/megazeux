#include <stdint.h>

void
some_thumb_code( uint8_t *an_array, uint32_t size) {
  int i;

  for ( i = 0; i < (int)size - 1; i++) {
    an_array[i] += an_array[i+1];
  }

  if ( size > 2) {
    if ( an_array[0] == 4) {
      an_array[1] = 6;
    }
    else {
      an_array[1] = 7;
    }
  }
}
